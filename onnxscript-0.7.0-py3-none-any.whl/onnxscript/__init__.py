# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

__all__ = [
    "script",
    "graph",
    "ir",
    "nn",
    "optimizer",
    "rewriter",
    "version_converter",
    "export_onnx_lib",
    "OnnxFunction",
    "TracedOnnxFunction",
    "GraphBuilder",
    "OpBuilder",
    "proto2python",
    "external_tensor",
    "BFLOAT16",
    "FLOAT16",
    "FLOAT8E4M3FN",
    "FLOAT8E4M3FNUZ",
    "FLOAT8E5M2",
    "FLOAT8E5M2FNUZ",
    "FLOAT",
    "DOUBLE",
    "INT8",
    "INT16",
    "INT32",
    "INT64",
    "UINT8",
    "UINT16",
    "UINT32",
    "UINT64",
    "BOOL",
    "STRING",
    "COMPLEX64",
    "COMPLEX128",
    "opset1",
    "opset2",
    "opset3",
    "opset4",
    "opset5",
    "opset6",
    "opset7",
    "opset8",
    "opset9",
    "opset10",
    "opset11",
    "opset12",
    "opset13",
    "opset14",
    "opset15",
    "opset16",
    "opset17",
    "opset18",
    "opset19",
    "opset20",
    "opset21",
    "opset22",
    "opset23",
    "opset_ai_onnx_ml1",
    "opset_ai_onnx_ml2",
    "opset_ai_onnx_ml3",
    "opset_ai_onnx_ml4",
    "opset_ai_onnx_ml5",
    "DEBUG",
]

import importlib.metadata

from ._internal.main import export_onnx_lib, graph, script
from .backend.onnx_export import export2python as proto2python

# isort: off
from .onnx_opset import (
    opset1,
    opset2,
    opset3,
    opset4,
    opset5,
    opset6,
    opset7,
    opset8,
    opset9,
    opset10,
    opset11,
    opset12,
    opset13,
    opset14,
    opset15,
    opset16,
    opset17,
    opset18,
    opset19,
    opset20,
    opset21,
    opset22,
    opset23,
    opset_ai_onnx_ml1,
    opset_ai_onnx_ml2,
    opset_ai_onnx_ml3,
    opset_ai_onnx_ml4,
    opset_ai_onnx_ml5,
)

from .onnx_types import (
    BFLOAT16,
    FLOAT16,
    FLOAT8E4M3FN,
    FLOAT8E4M3FNUZ,
    FLOAT8E5M2,
    FLOAT8E5M2FNUZ,
    FLOAT,
    DOUBLE,
    INT8,
    INT16,
    INT32,
    INT64,
    UINT8,
    UINT16,
    UINT32,
    UINT64,
    BOOL,
    STRING,
    COMPLEX64,
    COMPLEX128,
)

# isort: on

from . import ir, nn, optimizer, rewriter, version_converter
from ._internal.builder import GraphBuilder, OpBuilder
from ._internal.utils import external_tensor
from ._internal.values import OnnxFunction, TracedOnnxFunction

# Set DEBUG to True to enable additional debug checks
DEBUG: bool = False

try:  # noqa: SIM105
    __version__ = importlib.metadata.version("onnxscript")
except importlib.metadata.PackageNotFoundError:
    # package is not installed
    pass
